This is a simple website build using python 
It contains my favorite movie and i have given functionality to play its trailer
To run my website in localhost 
Open cmd prompt and type "python Movies.py"