import media
import fresh_tomatoes

#code describing all the details of the movie like the youtibe video link,poster image,description and name of the movie
Tinkerbell = media.Movie(
    "Tinkerbell",
    "Movie that tells about the about the life of a fairy named tinkerbell",
    "http://images.fun.com/products/21528/1-1/385-tinker-bell-giant-wall-decal-with-glitter.jpg",
    "https://youtu.be/ofvJ7KyulPA")
despicable_me_3 = media.Movie(
    "Despicable me 3",
    "Movie about a retired villan who comes back to action",
    "https://upload.wikimedia.org/wikipedia/en/9/91/Despicable_Me_3_%282017%29_Teaser_Poster.jpg",
    "https://youtu.be/6DBi41reeF0")
# list movies containing the list of movies
movies=[Tinkerbell,
        despicable_me_3]
# open movies webpage has arguments the list of movies 
fresh_tomatoes.open_movies_page(movies)



